szamolas = 6 * (1 - 2)

print(szamolas)