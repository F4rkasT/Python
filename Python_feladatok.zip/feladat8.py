for i in range(1000):
    print("Szeretjük a Python teknőcöket")