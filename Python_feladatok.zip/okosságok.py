napok = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"]

def nap(i):
    return napok[i]
    
print(nap(3))
