# Ez az első programunk
v = print("""Helló világ! ez egy hosszú sor 
yyyyyyyyyyyyyyyyyyyy""")

